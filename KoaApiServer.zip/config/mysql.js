const config = {
  // 启动端口
  PORT: 3000,
  DATABASE: 'peterchen',
  USER: 'peterchen',
  PASSWORD: 'admin',
  HOST: 'localhost'
}

module.exports = config