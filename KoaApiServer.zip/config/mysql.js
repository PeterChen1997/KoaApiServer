const config = {
  // 启动端口
  PORT: 3000,
  // DATABASE: 'blog',
  DATABASE: 'peterchen',
  USER: 'peterchen',
  // USER: 'root',
  PASSWORD: 'admin',
  PASSWORD: 'admin',
  HOST: 'localhost'
}

module.exports = config